#!/bin/bash

git status
git add -A
git commit -m "General updates, bug fixes, etc."
git push