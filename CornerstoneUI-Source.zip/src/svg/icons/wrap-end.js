	global.CornerstoneResources = CornerstoneResources;

})(this);